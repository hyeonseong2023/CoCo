import React from 'react'
import '../css/Footer.css'

const Footer = () => {
  return (
    <div className='Footer'>
      
    </div>
  )
}

export default Footer
