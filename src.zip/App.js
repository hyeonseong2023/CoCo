import './App.css';
import { Routes, Route } from 'react-router-dom'
import KakaoLogin from './components/KakaoLogin';
import KakaoCallback from './components/KakaoCallback';
import { KakaoJoin } from './components/KakaoJoin';


const App = () => {
  return (
    <div>
      {/* path(경로) : 사용자가 이렇게 요청 했을 때 
          element(컴포넌트) : 어떤컴포넌트를 보여줄지 */}
      <Routes>
        <Route path='/' element={<KakaoLogin/>} />
        <Route path='/auth/kakao/callback' element={<KakaoCallback/>} />
        <Route path='/join' element={<KakaoJoin/>} />
      </Routes>
    </div>
  )
}

export default App



















// function App() {
  
//   //카카오 개발자 앱 키 선언 
//    const REST_API_KEY = "23ddd7c45fb41d2db79ff49bd3a797c3";
//    const REDIRECT_URI = "http://localhost:3000/auth/kakao/callback";
//    const KAKAO_AUTH_URI = `http://kauth.kakao.com/oauth/authorize?client_id=${REST_API_KEY}&redirect_uri=${REDIRECT_URI}&response_type=code`;

//   // 1. CODE 받아오기 
//   const code = new URL(window.location.href).searchParams.get("code");
//   // new URL(window.location.href)  : 현재 페이지의 URL을 객체화 
//   // searchParams.get("code") : 'code' 라는 파라미터 값 추출 

  
//   // 2. 백엔드로 code 넘기기 
//   useEffect(()=>{
//     if(code){
//       fetchData();
//     }
//   },[code])

//  const fetchData = async ()=>{

//   try {
//       const res = await axios
//       .get(`http://localhost:8099/kakaocode?code=${code}`)
//       .then((response)=>{
//         console.log("응답확인", response);
//       })
//     } catch(e){
//       console.error(e);
//     }
    
//  }

// return (
//   <div><a href={KAKAO_AUTH_URI}>카카오</a></div>
// )


// }

// export default App;
